export class Requests
{
    username:string
    hospitalname:string
    mail:string
    phone:number
}