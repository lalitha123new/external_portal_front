import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import {ServerService} from '../server.service';
import { routerTransition } from '../config.service';
import {Requests} from './requests';
import {AuthServiceService} from '../auth-service.service';

@Component({
  selector: 'app-dash-board',
  templateUrl: './dash-board.component.html',
  styleUrls: ['./dash-board.component.css'],
  animations: [routerTransition()],
  host: {'[@routerTransition]': ''}
})
export class DashBoardComponent implements OnInit {
  active:string;
  hospitaldetails:Requests
  username= sessionStorage.getItem(name);
  
  constructor(private router: Router,private toastr: ToastrService,private serverService: ServerService,private Auth: AuthServiceService) {
    this.router.events.subscribe((val) => {
      this.routeChanged(val);
    });
  }

  ngOnInit() {
    this.gethospitaldetails();
  }

  routeChanged(val){
    this.active = val.url;
  }

  gethospitaldetails()
  {
    this.serverService.gethospitaldetails()
    .subscribe((response)=>{this.hospitaldetails=response
      console.log(response)}
    )
  }

  logOut(){
    this.Auth.logout();
  }
}
 